package InputOutput;

public class Document 
{
	public String content;
	public long wordCount;
	
	public Document(String docContent, long docWordCount)
	{
		content = docContent;
		wordCount = docWordCount;
	}
}
